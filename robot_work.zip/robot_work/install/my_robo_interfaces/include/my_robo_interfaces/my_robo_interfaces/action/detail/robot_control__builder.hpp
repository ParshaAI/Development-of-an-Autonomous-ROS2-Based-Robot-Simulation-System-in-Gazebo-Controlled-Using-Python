// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_robo_interfaces:action/RobotControl.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBO_INTERFACES__ACTION__DETAIL__ROBOT_CONTROL__BUILDER_HPP_
#define MY_ROBO_INTERFACES__ACTION__DETAIL__ROBOT_CONTROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_robo_interfaces/action/detail/robot_control__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_Goal_start_moving
{
public:
  explicit Init_RobotControl_Goal_start_moving(::my_robo_interfaces::action::RobotControl_Goal & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_Goal start_moving(::my_robo_interfaces::action::RobotControl_Goal::_start_moving_type arg)
  {
    msg_.start_moving = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Goal msg_;
};

class Init_RobotControl_Goal_camera_enabled
{
public:
  explicit Init_RobotControl_Goal_camera_enabled(::my_robo_interfaces::action::RobotControl_Goal & msg)
  : msg_(msg)
  {}
  Init_RobotControl_Goal_start_moving camera_enabled(::my_robo_interfaces::action::RobotControl_Goal::_camera_enabled_type arg)
  {
    msg_.camera_enabled = std::move(arg);
    return Init_RobotControl_Goal_start_moving(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Goal msg_;
};

class Init_RobotControl_Goal_angular_velocity
{
public:
  explicit Init_RobotControl_Goal_angular_velocity(::my_robo_interfaces::action::RobotControl_Goal & msg)
  : msg_(msg)
  {}
  Init_RobotControl_Goal_camera_enabled angular_velocity(::my_robo_interfaces::action::RobotControl_Goal::_angular_velocity_type arg)
  {
    msg_.angular_velocity = std::move(arg);
    return Init_RobotControl_Goal_camera_enabled(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Goal msg_;
};

class Init_RobotControl_Goal_linear_velocity
{
public:
  Init_RobotControl_Goal_linear_velocity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_Goal_angular_velocity linear_velocity(::my_robo_interfaces::action::RobotControl_Goal::_linear_velocity_type arg)
  {
    msg_.linear_velocity = std::move(arg);
    return Init_RobotControl_Goal_angular_velocity(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_Goal>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_Goal_linear_velocity();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_Result_status
{
public:
  Init_RobotControl_Result_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_robo_interfaces::action::RobotControl_Result status(::my_robo_interfaces::action::RobotControl_Result::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_Result>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_Result_status();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_Feedback_distance_to_obstacle
{
public:
  explicit Init_RobotControl_Feedback_distance_to_obstacle(::my_robo_interfaces::action::RobotControl_Feedback & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_Feedback distance_to_obstacle(::my_robo_interfaces::action::RobotControl_Feedback::_distance_to_obstacle_type arg)
  {
    msg_.distance_to_obstacle = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Feedback msg_;
};

class Init_RobotControl_Feedback_status
{
public:
  Init_RobotControl_Feedback_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_Feedback_distance_to_obstacle status(::my_robo_interfaces::action::RobotControl_Feedback::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_RobotControl_Feedback_distance_to_obstacle(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_Feedback>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_Feedback_status();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_SendGoal_Request_goal
{
public:
  explicit Init_RobotControl_SendGoal_Request_goal(::my_robo_interfaces::action::RobotControl_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_SendGoal_Request goal(::my_robo_interfaces::action::RobotControl_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_SendGoal_Request msg_;
};

class Init_RobotControl_SendGoal_Request_goal_id
{
public:
  Init_RobotControl_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_SendGoal_Request_goal goal_id(::my_robo_interfaces::action::RobotControl_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_RobotControl_SendGoal_Request_goal(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_SendGoal_Request>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_SendGoal_Request_goal_id();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_SendGoal_Response_stamp
{
public:
  explicit Init_RobotControl_SendGoal_Response_stamp(::my_robo_interfaces::action::RobotControl_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_SendGoal_Response stamp(::my_robo_interfaces::action::RobotControl_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_SendGoal_Response msg_;
};

class Init_RobotControl_SendGoal_Response_accepted
{
public:
  Init_RobotControl_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_SendGoal_Response_stamp accepted(::my_robo_interfaces::action::RobotControl_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_RobotControl_SendGoal_Response_stamp(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_SendGoal_Response>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_SendGoal_Response_accepted();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_GetResult_Request_goal_id
{
public:
  Init_RobotControl_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_robo_interfaces::action::RobotControl_GetResult_Request goal_id(::my_robo_interfaces::action::RobotControl_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_GetResult_Request>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_GetResult_Request_goal_id();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_GetResult_Response_result
{
public:
  explicit Init_RobotControl_GetResult_Response_result(::my_robo_interfaces::action::RobotControl_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_GetResult_Response result(::my_robo_interfaces::action::RobotControl_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_GetResult_Response msg_;
};

class Init_RobotControl_GetResult_Response_status
{
public:
  Init_RobotControl_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_GetResult_Response_result status(::my_robo_interfaces::action::RobotControl_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_RobotControl_GetResult_Response_result(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_GetResult_Response>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_GetResult_Response_status();
}

}  // namespace my_robo_interfaces


namespace my_robo_interfaces
{

namespace action
{

namespace builder
{

class Init_RobotControl_FeedbackMessage_feedback
{
public:
  explicit Init_RobotControl_FeedbackMessage_feedback(::my_robo_interfaces::action::RobotControl_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::my_robo_interfaces::action::RobotControl_FeedbackMessage feedback(::my_robo_interfaces::action::RobotControl_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_FeedbackMessage msg_;
};

class Init_RobotControl_FeedbackMessage_goal_id
{
public:
  Init_RobotControl_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotControl_FeedbackMessage_feedback goal_id(::my_robo_interfaces::action::RobotControl_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_RobotControl_FeedbackMessage_feedback(msg_);
  }

private:
  ::my_robo_interfaces::action::RobotControl_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_robo_interfaces::action::RobotControl_FeedbackMessage>()
{
  return my_robo_interfaces::action::builder::Init_RobotControl_FeedbackMessage_goal_id();
}

}  // namespace my_robo_interfaces

#endif  // MY_ROBO_INTERFACES__ACTION__DETAIL__ROBOT_CONTROL__BUILDER_HPP_
