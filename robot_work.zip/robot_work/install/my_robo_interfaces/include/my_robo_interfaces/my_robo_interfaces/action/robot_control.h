// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_robo_interfaces:action/RobotControl.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_H_
#define MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_H_

#include "my_robo_interfaces/action/detail/robot_control__struct.h"
#include "my_robo_interfaces/action/detail/robot_control__functions.h"
#include "my_robo_interfaces/action/detail/robot_control__type_support.h"

#endif  // MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_H_
