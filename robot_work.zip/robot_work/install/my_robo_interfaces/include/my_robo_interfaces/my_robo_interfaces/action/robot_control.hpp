// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_HPP_
#define MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_HPP_

#include "my_robo_interfaces/action/detail/robot_control__struct.hpp"
#include "my_robo_interfaces/action/detail/robot_control__builder.hpp"
#include "my_robo_interfaces/action/detail/robot_control__traits.hpp"
#include "my_robo_interfaces/action/detail/robot_control__type_support.hpp"

#endif  // MY_ROBO_INTERFACES__ACTION__ROBOT_CONTROL_HPP_
