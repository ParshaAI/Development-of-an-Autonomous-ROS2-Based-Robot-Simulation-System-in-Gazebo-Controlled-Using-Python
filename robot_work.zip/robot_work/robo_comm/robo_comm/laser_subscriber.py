import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

class Laser_Subscriber(Node):

    def __init__(self):
        super().__init__('laser_subscriber')
        
        
        self.subscription = self.create_subscription(
            LaserScan,        
            '/laser_scan',    
            self.listener_callback,  
            10                
        )

        self.closest_distance = float('inf')
        self.subscription  

    def listener_callback(self, msg):
        
        self.closest_distance = min(msg.ranges)
        self.get_logger().info('Closest distance: %.2f meters' % self.closest_distance)

    def get_closest_distance(self):
        return self.closest_distance

def main(args=None):
    rclpy.init(args=args)
    laser_subscriber = Laser_Subscriber()
    rclpy.spin(laser_subscriber)
    laser_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
