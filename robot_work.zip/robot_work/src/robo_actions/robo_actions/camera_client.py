import rclpy
from rclpy.node import Node
from my_package.action import CameraControl
from rclpy.action import ActionClient

class CameraControlClient(Node):
    def __init__(self):
        super().__init__('camera_client')
        self._action_client = ActionClient(self, CameraControl, 'control_camera')

    def send_goal(self, angle):
        goal_msg = CameraControl.Goal()
        goal_msg.angle = angle
        
        # Send the goal to the action server
        self._action_client.send_goal_async(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    camera_client = CameraControlClient()
    camera_client.send_goal(1.0)  # Rotate camera to 1 rad (about 57.3 degrees)
    rclpy.spin(camera_client)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
