import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class Camera_Control(Node):
    def __init__(self):
        super().__init__('camera_control')

        
        self.camera_joint_pub = self.create_publisher(Float64, '/camera_rod/joint_position_controller/command', 10)
        
  
        self.image_subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )

       
        self.br = CvBridge()

    def image_callback(self, msg):
        try:
            
            cv_image = self.br.imgmsg_to_cv2(msg, 'bgr8')

         
            cv2.imshow("Camera Image", cv_image)
            cv2.waitKey(1)
        except Exception as e:
            self.get_logger().error(f"Error processing image: {e}")

    def rotate_camera(self, angle):
        """ Rotate the camera to a specific angle using the revolute joint """
        msg = Float64()
        msg.data = angle 
        self.camera_joint_pub.publish(msg)
        self.get_logger().info(f"Rotating camera to angle: {angle} radians")


def main(args=None):
    rclpy.init(args=args)

    camera_control = Camera_Control()

   
    camera_control.rotate_camera(0.5)  
    
    rclpy.spin(camera_control)

    camera_control.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
