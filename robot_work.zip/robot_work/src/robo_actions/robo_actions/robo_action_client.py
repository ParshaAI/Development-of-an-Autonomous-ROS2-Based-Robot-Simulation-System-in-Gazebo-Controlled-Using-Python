import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from my_robo_interfaces.action import RobotControl  # Ensure this is the correct import path
from geometry_msgs.msg import Twist


class Robot_Action_Client(Node):

    def __init__(self):
        super().__init__('robo_action_client')

        # Create the action client
        self._action_client = ActionClient(self, RobotControl, 'robot_control')

    def send_goal(self):
        # Create a goal message
        goal_msg = RobotControl.Goal()

        # Example: Set a goal to start the robot and avoid obstacles
        goal_msg.start_moving = True  # This could be customized based on your action definition
        
        #goal_msg.linear_velocity = 0.5  # Set linear velocity for movement
       # goal_msg.angular_velocity = 0.1 
        # Wait for the server to be available
        self._action_client.wait_for_server()

        # Send goal to the server and provide a feedback callback
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback)

        # Add a callback for goal acceptance
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()

        # Check if the goal is accepted by the server
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self.get_logger().info('Goal accepted :)')

        # Wait for result and handle the result callback
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Result: {0}'.format(result.status))
        rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        # Receive feedback from the action server
        feedback = feedback_msg.feedback
        self.get_logger().info('Received feedback: {0}'.format(feedback.status))


def main(args=None):
    rclpy.init(args=args)

    # Create an action client instance
    action_client = Robot_Action_Client()

    # Send the goal to start the robot
    action_client.send_goal()

    # Keep spinning to listen for feedback and results
    rclpy.spin(action_client)


if __name__ == '__main__':
    main()
