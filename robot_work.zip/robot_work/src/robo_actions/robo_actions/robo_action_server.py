import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry  
import math

class Robot_Action_Server(Node):
    def __init__(self):
        super().__init__('robot_action_server')
        self.subscription = self.create_subscription(LaserScan, '/laser_scan', self.lidar_callback, 10)
        self.publisher = self.create_publisher(Twist, '/model/vehicle_blue/cmd_vel', 10)

    def lidar_callback(self,msg):
        num_points = len(msg.ranges)

        right = msg.ranges[:num_points // 3]
        front = msg.ranges[num_points // 3 : 2 * num_points // 3]
        left = msg.ranges[2 * num_points // 3 :]

        right_min = min([r for r in right if r > msg.range_min], default = float('inf'))
        front_min = min([f for f in front if f> msg.range_min], default = float('inf'))
        left_min = min([l for l in left if l > msg.range_min], default = float('inf'))

        self.get_logger().info(f"Right: {right_min:.2f}, Front: {front_min:.2f}, Left: {left_min:.2f}")

        cmd = Twist()

        if front_min < 4.0:
            if left_min > right_min:
                self.get_logger().warn("Obstacle in front, more space in left, turning left")
                cmd.linear.x = -0.5
                cmd.angular.z = 0.5 #left
                
                

            elif left_min == right_min:
                cmd.linear.x = -0.5
                cmd.angular.z = 0.5 #right
                


            else:
                self.get_logger().warn("Obstacle in front, more space on right, turning right")
                cmd.linear.x = -0.5
                cmd.angular.z = -0.5
                
                


        else:
            if right_min < 2.0 and left_min > 2.0:
                self.get_logger().warn("Obstacle on right, turning left")
                cmd.angular.z = 0.5 #left
                cmd.linear.x = 0.5

            elif left_min < 2.0 and right_min > 2.0:
                self.get_logger().warn("obstacle on left, turning right")
                cmd.angular.z = -0.5
                cmd.linear.x = 0.5
                

            else:
                self.get_logger().info("Path clear, moving on")
                cmd.linear.x = 0.5
                cmd.angular.z = 0.5

        self.publisher.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = Robot_Action_Server()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ =="__main__":
    main()








            
            